
public class radioCar {

	private int id;
	private String name;
	private String feature;
	
	public radioCar(int id,String name, String feature) {
		this.id = id;
		this.name = name;	
		this.feature = feature;
	}
	
	public int ID() {
		return id ;
	}
	
	
	public String getName() {
		return name;
		
	}
	
	public String getFeature() {
		return feature;
	}

}
