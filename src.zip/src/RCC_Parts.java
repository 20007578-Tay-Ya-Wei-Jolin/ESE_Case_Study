import java.util.ArrayList;

/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Erh Zhi Jun
 * Student ID: 20011589
 * Class: W64F
 * Date/Time created: Sunday 15-08-2021 22:07
 */

public class RCC_Parts extends RCCP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<RCCP> rccpList = new ArrayList<RCCP>();
		int option = 0;
		while (option != 5) {
			menu();
			option = Helper.readInt("Enter option > ");
			if (option == 1) {
				// ethan's part
			} else if (option == 2) {
				/// jolin's part
			} else if (option == 3) {
				int option1 = 0;
				while (option != 4) {
					parts_menu();
					if (option1 == 1) {
						// add
						rccpAdd(rccpList);
					} else if (option1 == 2) {
						// delete
						rccpDel();
					} else if (option1 == 3) {
						// view
						rccpView();
					} else if (option1 == 4) {
						System.out.println("GoodBye!");
					} else {
						System.out.println("Invalid Option!");
					}
				}

			} else if (option == 4) {
				// tengyik's part
			} else if (option == 5) {
				System.out.println("GoodBye!");
			}
		}
	}

	private static void menu() {
		Helper.line(80, "-");
		System.out.println("1. Visitor Registration");
		System.out.println("2. View cars");
		System.out.println("3. View parts");
		System.out.println("4. Display appointment schedule");
		System.out.println("5. Quit");
		Helper.line(80, "-");
	}

	private static void parts_menu() {
		Helper.line(80, "=");
		System.out.println("1. Add Car Parts");
		System.out.println("2. Delete Car Parts");
		System.out.println("3. View Car Parts");
		System.out.println("4. Exit");
		Helper.line(80, "=");

	}private static void rccpAdd(ArrayList<RCCP>rccpList) {
		String addID = Helper.readString("Input Product ID > ");
		String addName = Helper.readString("Input name of part > ");
		boolean check = true;
		for(RCCP R : rccpList) {
			if (R.getProductID().equalsIgnoreCase(addID)) {
				System.out.println("Product ID already exists");
				check = false;
			}				
		}if (check = true) {
			RCCP rccpnew = new RCCP(addID, addName);
			rccpList.add(rccpnew);
		}
	}
	
	private static void rccpDel() {
		
	}
	
	private static void rccpView() {
		
	}
}
