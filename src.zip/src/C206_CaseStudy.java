import java.util.ArrayList;

public class C206_CaseStudy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int option = 0;

		while (option != 5) {
			
			
			
			

			C206_CaseStudy.menu();
			option = Helper.readInt("Enter an option > ");

			if (option == 1) {
				// ethan's part
			} else if (option == 2) {
				int option1 = 0;
				listing_Features_menu();
				option1 = Helper.readInt("Enter choice > ");
				if (option1 == 1) {
					// add
					AddradioCar();
				} else if (option1 == 2) {
					// delete
					DelradioCar();
				} else if (option1 == 3) {
					// view
					ViewradioCar();
				} else if (option1 == 4) {
					System.out.println("GoodBye!");
				} else {
					System.out.println("Invalid Option!");
				}
				
			} else if (option == 3) {
				// Zhi jun's part
			} else if (option == 4) {
				// tengyik's part
			} else if (option == 5) {
				System.out.println("GoodBye!");
			}
		}
	}

	private static void menu() {
		Helper.line(80, "-");
		System.out.println("1. Visitor Registration");
		System.out.println("2. View cars");
		System.out.println("3. View parts");
		System.out.println("4. Display appointment schedule");
		System.out.println("5. Quit");
		Helper.line(80, "-");
	}

	private static void listing_Features_menu() {
		
		Helper.line(80, "=");
		
		System.out.println("1. AddradioCAr");
		System.out.println("2. DeleteradioCar");
		System.out.println("3. ViewradioCar");
		System.out.println("4. Exit");
		
		Helper.line(80, "=");

	}private static void AddradioCar() {
		ArrayList <radioCar> radioCarList = new ArrayList<radioCar>();
		
		int id = Helper.readInt("Enter id");
		String name = Helper.readString("Enter model");
		String feature = Helper.readString("Enter features");
		
		radioCar radioCar = new radioCar(id ,name , feature);
		radioCarList.add(radioCar);
		System.out.print("New radiocar Added ! \n");
		
		
	}
	
	private static void DelradioCar() {
		ArrayList <radioCar> radioCarList = new ArrayList<radioCar>();
		
		int id = Helper.readInt("Enter id");
		
		for (int i = 0; i < radioCarList.size(); i++) {
			int id1 = radioCarList.get(i).ID();
			
			if (id == id1) {
				radioCarList.remove(i);
				System.out.println("id = " + id + "is removed");
				
			}else {
				System.out.println("Error id");
			}
		}
		
	}
	
	private static void ViewradioCar() {
		String output = "";
		ArrayList <radioCar> radioCarList = new ArrayList<radioCar>();
		for (int i = 0; i < radioCarList.size(); i++) {
			output += String.format("%s , %5s , %5s", "id" , "name", "features");
			output += String.format("%d , %5s , %5s", radioCarList);
	
		}
		
		System.out.println(output);
		
		
		
	}

	
}