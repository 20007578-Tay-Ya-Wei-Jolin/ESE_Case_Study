/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Erh Zhi Jun
 * Student ID: 20011589
 * Class: W64F
 * Date/Time created: Sunday 15-08-2021 23:24
 */

public class RCCP {
	private String productID;
	private String name;
	
	public RCCP(String addID, String addName) {
		this.productID = productID;
		this.name = name;	
	}
	public String getProductID() {
		return productID;
	}
	public String getName() {
		return name;
	}

}
