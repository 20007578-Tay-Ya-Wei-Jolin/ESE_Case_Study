import java.util.ArrayList;

public class account {
	public static void main(String[] args) {
		ArrayList<String> name = new ArrayList<String>();
		name.add("Jeffery");
		name.add("Adam");
		name.add("Allen");
		name.add("Maarry");
		System.out.println(name);
	}
}